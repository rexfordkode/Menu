package com.example.moftech.smartmenu.Common;

public class Config {

    public static final String PAYPAL_CLIENT_ID = "AY24dzzExFDDbWhuon7naG5nTQZ_vcwInn8ofb3DZDoqOHuMYlAx-xWleN2TSzzrioo2jdm5wxC2JD1c";

}
