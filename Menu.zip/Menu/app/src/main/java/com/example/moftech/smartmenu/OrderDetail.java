package com.example.moftech.smartmenu;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class OrderDetail extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_detail);
    }
}
