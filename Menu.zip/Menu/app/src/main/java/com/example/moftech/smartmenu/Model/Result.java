package com.example.moftech.smartmenu.Model;

public class Result {

    public  String message_id;
}
